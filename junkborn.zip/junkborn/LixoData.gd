class_name LixoData
extends Resource

@export var item_id: int 
@export var nome: String = ""
@export_multiline var descricao: String = ""
@export var textura: Texture2D
@export_enum("Vidro", "Metal", "Plastico", "Papel", "Nada") var tipoDeLixo: String = "Algo"
@export var Coletavel: bool = true
@export var pode_desmanchar: bool = false
