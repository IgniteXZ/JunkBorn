extends Area2D


var perto: bool = false


func _ready() -> void:
	pass

func _process(delta: float) -> void:
	if perto and Input.is_action_just_pressed("Interagir"):
		print("Aperte E para entrar na forja")
		Global.trocar_cena(
			"res://Cenarios/CenarioVila/characterP.tscn",
			"spawnsVila/sairDesertoParaVila"
		)
		


func _on_area_entered(area: Area2D) -> void:
	perto = true


func _on_area_exited(area: Area2D) -> void:
	perto = false
