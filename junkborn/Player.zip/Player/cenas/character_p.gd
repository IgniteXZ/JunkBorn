extends Node2D
@export var mandacaru: CharacterBody2D
@export var npc: CharacterBody2D
@onready var Player = $"y-sort/Character"
@export var musica: AudioStream
func _ready() -> void:
	Global.cidade_atual = 0
	AudioManager.tocar_musica(musica)
	
	if not Global.eventos.get("intro_vila", false):
		Player.process_mode = Node.PROCESS_MODE_DISABLED
		await TelaAto.aguardar()
		start_dialog()
		
	
	if Dialogic.VAR.deserto_liberado == true and Global.cidade_atual == 0:
		mandacaru.queue_free()
		npc.queue_free()


func start_dialog():
	Dialogic.timeline_ended.connect(_on_timeline_ended)
	Dialogic.start("filomenoChegaVila")
	Player.process_mode = Node.PROCESS_MODE_DISABLED

func _on_timeline_ended():
	Global.eventos["intro_vila"] = true
	Dialogic.timeline_ended.disconnect(_on_timeline_ended)
	Player.process_mode = Node.PROCESS_MODE_INHERIT
	Tutorial.mostrar("andar", "<move_up><move_left><move_down><move_right> ou as setas|para andar", "move_left move_right move_up move_down")
